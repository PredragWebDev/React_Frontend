# naijaTrading

Changing Naija trading experience. Making Nigeria a better place for trading
