import datetime
from apps.simulator import blueprint
import re
import time
from apps import db
from flask import render_template, request, redirect, url_for, flash
from flask_login import login_required
from jinja2 import TemplateNotFound
import investpy as inv
import pandas as pd
from apps.authentication.models import Users
from apps.simulator.models import Portfolio, PortfolioChart
from flask_login import (
    current_user
)

stockprice, companyNames = {}, {}
data = pd.read_csv("companyInfo.csv")
stocks = data['Ticker']


def stockPriceUpdate():
    for stock in stocks:
        search_result = inv.search_quotes(text=stock, products=['stocks'],
                                          countries=['Nigeria'], n_results=1)
        information = search_result.retrieve_information()
        stockprice[stock] = information['prevClose']


def chartDataUpdate():
    username = str(current_user)
    user = Users.query.filter_by(username=username).first()
    account_balance = user.cash
    portfolio = Portfolio.query.filter_by(username=username)
    for item in portfolio:
        item.current_price = stockprice[item.symbol]
        account_balance += item.current_price * item.qty
    values = PortfolioChart(
        username=username, account_balance=account_balance, date=datetime.datetime.now())
    db.session.add(values)
    db.session.commit()


@blueprint.route('/portfolio')
@login_required
def portfolio():
    chartDataUpdate()
    global stocks
    data = pd.read_csv("companyInfo.csv")
    for i in range(len(data)):
        companyNames[data['Ticker'][i]] = data['Name'][i]
    username = str(current_user)
    user = Users.query.filter_by(username=username).first()
    account_balance = user.cash
    inv_amount = user.invested_amount
    cash = user.cash
    portfolio = Portfolio.query.filter_by(username=username)
    for item in portfolio:
        item.current_price = stockprice[item.symbol]
        db.session.add(item)
        db.session.commit()
        account_balance += item.current_price * item.qty
    print(account_balance)
    user = Users.query.filter_by(username=username).first()
    user.account_balance = account_balance
    db.session.add(user)
    db.session.commit()

    inv_profit = account_balance - user.cash - inv_amount
    try:
        percentage = (inv_profit / inv_amount)*100
    except:
        percentage = 0

    chartData = []
    chartDates = []
    chartByUser = PortfolioChart.query.filter_by(username=username)
    for chart in chartByUser:
        chartData.append(chart.account_balance)
        chartDates.append(chart.date)
    # print(chartDates, chartData)
    return render_template('simulator/portfolio.html', chartData=chartData, chartDates=chartDates, account_balance=account_balance, inv_amount=inv_amount, profit=inv_profit, percentage=percentage, cash=cash, portfolio=portfolio, companyNames=companyNames, segment='portfolio')


@blueprint.route('/trade', methods=['GET', 'POST'])
@login_required
def trade():
    # print(stockprice)
    data['symbolNames'] = data['Ticker'] + " - " + data['Name']
    symbolNames = sorted(list(data['symbolNames']))
    # print(symbolNames)
    username = str(current_user)
    user = Users.query.filter_by(username=username).first()

    print(user.account_balance, user.invested_amount)
    if request.method == 'POST':
        action = request.form['action']
        qty = int(request.form['qty'])
        ticker_dropdown = request.form['ticker'].split("-")
        ticker = ticker_dropdown[0].replace(" ", "")

        if action == 'buy':
            if user.cash >= float(qty) * stockprice[ticker]:
                user.cash -= float(qty) * stockprice[ticker]
                user.invested_amount += float(qty) * stockprice[ticker]
                # print(user.account_balance, user.invested_amount)
                db.session.add(user)
                db.session.commit()

                existingRecord = Portfolio.query.filter_by(
                    symbol=ticker, username=username).first()
                if existingRecord:
                    existingRecord.qty += qty
                    existingRecord.purchase_price = (
                        existingRecord.purchase_price + stockprice[ticker])/2
                    db.session.add(existingRecord)
                    db.session.commit()

                else:
                    portfolio = Portfolio(symbol=ticker, current_price=stockprice[ticker], qty=qty,
                                          username=username, purchase_price=stockprice[ticker])
                    db.session.add(portfolio)
                    db.session.commit()
                return redirect(url_for('simulator_blueprint.portfolio'))

            else:
                flash("This order did not execute because your account has insufficient Cash (or margin) remaining to execute the order.", 'danger')
                return redirect(url_for('simulator_blueprint.trade'))

        if action == 'sell':
            portfolio = Portfolio.query.filter_by(
                symbol=ticker, username=username).first()
            print(portfolio)
            # portfolioUser = Portfolio.query.filter_by(username=username)
            # portfolio = list(set(portfolioTicker) & set(portfolioUser))
            if portfolio.qty > qty:
                user.cash += float(qty) * stockprice[ticker]
                user.invested_amount -= float(qty) * stockprice[ticker]
                # print(user.cash, user.invested_amount)
                db.session.add(user)
                db.session.commit()

                portfolio.qty -= qty
                db.session.add(portfolio)
                db.session.commit()
            elif portfolio.qty == qty:
                user.cash += float(qty) * stockprice[ticker]
                user.invested_amount -= float(qty) * stockprice[ticker]
                # print(user.cash, user.invested_amount)
                db.session.add(user)
                db.session.commit()

                db.session.delete(portfolio)
                db.session.commit()
            else:
                flash("You don't own the amount of stock your trying to sell", 'danger')
                return redirect(url_for('simulator_blueprint.trade'))
            return redirect(url_for('simulator_blueprint.portfolio'))
            # remove from portfolio table

    return render_template('simulator/trade.html', symbolNames=symbolNames, segment='trade')


@blueprint.route('/scoreboard', methods=['GET', 'POST'])
@login_required
def scoreboard():
    users = Users.query.order_by(Users.account_balance).all()

    return render_template('simulator/scoreboard.html', segment='scoreboard', users=users)
