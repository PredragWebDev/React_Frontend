from datetime import date

from apps import db


class Portfolio(db.Model):

    __tablename__ = 'portfolio'

    symbol = db.Column(db.String(64), primary_key=True)
    desc = db.Column(db.String(64))
    current_price = db.Column(db.Float)  # we're using prev close
    purchase_price = db.Column(db.Float)
    qty = db.Column(db.Integer)
    date = db.Column(db.Date, default=date.today())
    username = db.Column(db.String(64))

    def __repr__(self):
        return str(self.symbol)


class PortfolioChart(db.Model):

    __tablename__ = 'portfoliochart'

    id = db.Column(db.Integer, primary_key=True)
    account_balance = db.Column(db.Float)  # we'll use prev close
    date = db.Column(db.Date, default=date.today())
    username = db.Column(db.String(64))

    def __repr__(self):
        return str(self.symbol)
