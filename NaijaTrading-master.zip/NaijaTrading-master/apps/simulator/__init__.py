from flask import Blueprint

blueprint = Blueprint(
    'simulator_blueprint',
    __name__,
    url_prefix=''
)
