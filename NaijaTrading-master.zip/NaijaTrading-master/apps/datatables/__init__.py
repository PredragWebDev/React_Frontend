from flask import Blueprint

blueprint = Blueprint(
    'datatables_blueprint',
    __name__,
    url_prefix=''
)
